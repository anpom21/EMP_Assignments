/*
 * string.h
 *
 *  Created on: 26/12/2011
 *      Author: Morten
 */
#include "file.h"

void putc1( FILE, unsigned char );
const void gfprintf( FILE, const char*, ...);
const void gsprintf( INT8U*, const char*, ...);
const void gprintf( const char *, ...);
